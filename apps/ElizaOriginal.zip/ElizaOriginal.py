from tkinter import *
import re
import random
from deep_translator import GoogleTranslator
from tkinter.scrolledtext import ScrolledText
from os import path


directory = path.dirname(__file__)





system_language = 'en'
user_language = 'iw'
is_win_open = True

translator_to_output_lang = GoogleTranslator(
    source=system_language, target=user_language)

translator_to_english = GoogleTranslator(
    source=user_language, target=system_language)

last_answer = ''






class Eliza:
  def __init__(self):
    self.keys = list(map(lambda x: re.compile(x[0], re.IGNORECASE), gPats))
    self.values = list(map(lambda x: x[1], gPats))

  #----------------------------------------------------------------------
  # translate: take a string, replace any words found in vocabulary.keys()
  #  with the corresponding vocabulary.values()
  #----------------------------------------------------------------------
  def translate(self, text, vocabulary):
    words = text.lower().split()
    keys = vocabulary.keys()
    for i in range(0, len(words)):
      if words[i] in keys:
        words[i] = vocabulary[words[i]]
    return ' '.join(words)

  #----------------------------------------------------------------------
  #  respond: take a string, a set of regexps, and a corresponding
  #    set of response lists; find a match, and return a randomly
  #    chosen response from the corresponding list.
  #----------------------------------------------------------------------
  def respond(self, text):
    # find a match among keys
    for i in range(0, len(self.keys)):
      match = self.keys[i].match(text)
      if match:
        # found a match ... stuff with corresponding value
        # chosen randomly from among the available options
        resp = random.choice(self.values[i])
        # we've got a response... stuff in reflected text where indicated
        pos = resp.find('%')
        while pos > -1:
          num = int(resp[pos+1:pos+2])
          resp = resp[:pos] + \
            self.translate(match.group(num), gReflections) + \
            resp[pos+2:]
          pos = resp.find('%')
        # fix munged punctuation at the end
        if resp[-2:] == '?.': resp = resp[:-2] + '.'
        if resp[-2:] == '??': resp = resp[:-2] + '?'
        return resp
    return None

#----------------------------------------------------------------------
# gReflections, a translation table used to convert things you say
#    into things the computer says back, e.g. "I am" --> "you are"
#----------------------------------------------------------------------
gReflections = {
  "am"   : "are",
  "was"  : "were",
  "i"    : "you",
  "i'd"  : "you would",
  "i've"  : "you have",
  "i'll"  : "you will",
  "my"  : "your",
  "are"  : "am",
  "you've": "I have",
  "you'll": "I will",
  "your"  : "my",
  "yours"  : "mine",
  "you"  : "me",
  "me"  : "you"
}

#----------------------------------------------------------------------
# gPats, the main response table.  Each element of the list is a
#  two-element list; the first is a regexp, and the second is a
#  list of possible responses, with group-macros labelled as
#  %1, %2, etc.
#----------------------------------------------------------------------
gPats = [
  [r'I need (.*)',
  [  "Why do you need %1?",
    "Would it really help you to get %1?",
    "Are you sure you need %1?"]],

  [r'Why don\'?t you ([^\?]*)\??',
  [  "Do you really think I don't %1?",
    "Perhaps eventually I will %1.",
    "Do you really want me to %1?"]],

  [r'Why can\'?t I ([^\?]*)\??',
  [  "Do you think you should be able to %1?",
    "If you could %1, what would you do?",
    "I don't know -- why can't you %1?",
    "Have you really tried?"]],

  [r'I can\'?t (.*)',
  [  "How do you know you can't %1?",
    "Perhaps you could %1 if you tried.",
    "What would it take for you to %1?"]],

  [r'I am (.*)',
  [  "Did you come to me because you are %1?",
    "How long have you been %1?",
    "How do you feel about being %1?"]],

  [r'I\'?m (.*)',
  [  "How does being %1 make you feel?",
    "Do you enjoy being %1?",
    "Why do you tell me you're %1?",
    "Why do you think you're %1?"]],

  [r'Are you ([^\?]*)\??',
  [  "Why does it matter whether I am %1?",
    "Would you prefer it if I were not %1?",
    "Perhaps you believe I am %1.",
    "I may be %1 -- what do you think?"]],

  [r'What (.*)',
  [  "Why do you ask?",
    "How would an answer to that help you?",
    "What do you think?"]],

  [r'How (.*)',
  [  "How do you suppose?",
    "Perhaps you can answer your own question.",
    "What is it you're really asking?"]],

  [r'Because (.*)',
  [  "Is that the real reason?",
    "What other reasons come to mind?",
    "Does that reason apply to anything else?",
    "If %1, what else must be true?"]],

  [r'(.*) sorry (.*)',
  [  "There are many times when no apology is needed.",
    "What feelings do you have when you apologize?"]],

  [r'Hello(.*)',
  [  "Hello... I'm glad you could drop by today.",
    "Hi there... how are you today?",
    "Hello, how are you feeling today?"]],

  [r'I think (.*)',
  [  "Do you doubt %1?",
    "Do you really think so?",
    "But you're not sure %1?"]],

  [r'(.*) friend (.*)',
  [  "Tell me more about your friends.",
    "When you think of a friend, what comes to mind?",
    "Why don't you tell me about a childhood friend?"]],

  [r'Yes',
  [  "You seem quite sure.",
    "OK, but can you elaborate a bit?"]],

  [r'(.*) computer(.*)',
  [  "Are you really talking about me?",
    "Does it seem strange to talk to a computer?",
    "How do computers make you feel?",
    "Do you feel threatened by computers?"]],

  [r'Is it (.*)',
  [  "Do you think it is %1?",
    "Perhaps it's %1 -- what do you think?",
    "If it were %1, what would you do?",
    "It could well be that %1."]],

  [r'It is (.*)',
  [  "You seem very certain.",
    "If I told you that it probably isn't %1, what would you feel?"]],

  [r'Can you ([^\?]*)\??',
  [  "What makes you think I can't %1?",
    "If I could %1, then what?",
    "Why do you ask if I can %1?"]],

  [r'Can I ([^\?]*)\??',
  [  "Perhaps you don't want to %1.",
    "Do you want to be able to %1?",
    "If you could %1, would you?"]],

  [r'You are (.*)',
  [  "Why do you think I am %1?",
    "Does it please you to think that I'm %1?",
    "Perhaps you would like me to be %1.",
    "Perhaps you're really talking about yourself?"]],

  [r'You\'?re (.*)',
  [  "Why do you say I am %1?",
    "Why do you think I am %1?",
    "Are we talking about you, or me?"]],

  [r'I don\'?t (.*)',
  [  "Don't you really %1?",
    "Why don't you %1?",
    "Do you want to %1?"]],

  [r'I feel (.*)',
  [  "Good, tell me more about these feelings.",
    "Do you often feel %1?",
    "When do you usually feel %1?",
    "When you feel %1, what do you do?"]],

  [r'I have (.*)',
  [  "Why do you tell me that you've %1?",
    "Have you really %1?",
    "Now that you have %1, what will you do next?"]],

  [r'I would (.*)',
  [  "Could you explain why you would %1?",
    "Why would you %1?",
    "Who else knows that you would %1?"]],

  [r'Is there (.*)',
  [  "Do you think there is %1?",
    "It's likely that there is %1.",
    "Would you like there to be %1?"]],

  [r'My (.*)',
  [  "I see, your %1.",
    "Why do you say that your %1?",
    "When your %1, how do you feel?"]],

  [r'You (.*)',
  [  "We should be discussing you, not me.",
    "Why do you say that about me?",
    "Why do you care whether I %1?"]],

  [r'Why (.*)',
  [  "Why don't you tell me the reason why %1?",
    "Why do you think %1?" ]],

  [r'I want (.*)',
  [  "What would it mean to you if you got %1?",
    "Why do you want %1?",
    "What would you do if you got %1?",
    "If you got %1, then what would you do?"]],

  [r'(.*) mother(.*)',
  [  "Tell me more about your mother.",
    "What was your relationship with your mother like?",
    "How do you feel about your mother?",
    "How does this relate to your feelings today?",
    "Good family relations are important."]],

  [r'(.*) father(.*)',
  [  "Tell me more about your father.",
    "How did your father make you feel?",
    "How do you feel about your father?",
    "Does your relationship with your father relate to your feelings today?",
    "Do you have trouble showing affection with your family?"]],

  [r'(.*) child(.*)',
  [  "Did you have close friends as a child?",
    "What is your favorite childhood memory?",
    "Do you remember any dreams or nightmares from childhood?",
    "Did the other children sometimes tease you?",
    "How do you think your childhood experiences relate to your feelings today?"]],

  [r'(.*)\?',
  [  "Why do you ask that?",
    "Please consider whether you can answer your own question.",
    "Perhaps the answer lies within yourself?",
    "Why don't you tell me?"]],

  [r'quit',
  [  "Thank you for talking with me.",
    "Good-bye.",
    "Thank you, that will be $150.  Have a good day!"]],

  [r"(^|\s)(no|NO|No|nO)($|\s)",
      [
          "Are you just saying NO to be negitive?",
          "What about some agreement?"
      ]
  ],

  [r'(.*)',
  [  "Please tell me more.",
    "Let's change focus a bit... Tell me about your family.",
    "Can you elaborate on that?",
    "Why do you say that %1?",
    "I see.",
    "Very interesting.",
    "%1.",
    "I see.  And what does that tell you?",
    "How does that make you feel?",
    "How do you feel when you say that?"]]
  ]


win = Tk()
win.title('אליזה "המקורית" 1')
win.config(bg='black')
win.state('zoomed')


def no_internet():
    global win
    global is_win_open

    is_win_open = False
    w = Tk()
    win.destroy()
    Label(w, text='🌐No Internet Eliza can not work without internet!אין אינטרנט ואליזה לא יכולה לעבוד בלי אינטרנט',
          font=('Rod', '20'), bg='red', fg='blue').pack()
    w.mainloop()




win.iconbitmap(f'{directory}\icon.ico')


def close():
    global win
    win.destroy()
    global is_win_open
    is_win_open = False


win.protocol('WM_DELETE_WINDOW', close)

textbox = ScrolledText(win, width=100, height=30, bg='black',
                       fg='white', borderwidth=0, undo=True, font='Terminal')

textbox.tag_configure('direction', justify='right')

textbox.pack(side=TOP)
textbox.insert(END, '"אליזה הפסיכולוגית המקורית"', 'direction')
textbox.insert(END, '\n'+'-'*50+'\n', 'direction')
textbox.insert(
    END, '!שלום', 'direction')
textbox.config(state=DISABLED, cursor='arrow')
entry = Entry(win, width=100, bg='black', fg='white',
              font=('Terminal', '15'), borderwidth=1, insertbackground='white')
entry.pack(side=TOP, pady=20)


def scroll_to_bottom(widget: Text):
    text = widget
    int1 = int(text.index('end').split('.')[0])-1
    text.yview(MOVETO, int1)


eliza = Eliza()

lastQnoTranslate = str()

printHead = '<'

last_answer_holder_for_answer_repeat_check = str()

def talk(event):
    try:
        win.config(cursor='wait')
        textbox.config(cursor='wait')
        entry.config(cursor='wait')
        drop.config(cursor='wait')
        lf.config(cursor='wait')

        if True:
            global last_answer
            global lastQnoTranslate
            global last_answer_holder_for_answer_repeat_check

        direct_user_input = entry.get()
        lastQnoTranslate = direct_user_input
        if not direct_user_input.isalnum():
            direct_user_input = direct_user_input + '.'
            
        try:
            user_input_translated = str(translator_to_english.translate(
                direct_user_input))
        except:
            no_internet()


        answer = eliza.respond(user_input_translated)
        while answer == last_answer_holder_for_answer_repeat_check:
            answer = eliza.respond(user_input_translated)
        last_answer_holder_for_answer_repeat_check = answer


        if not '\n' in answer:
            translated_answer = translator_to_output_lang.translate(answer)
            if len(translated_answer) > 130:
                for i in range(0, 141):
                    val = translated_answer[::-1][i]
                    if val == ' ':
                        index = -i
                        translated_answer = translated_answer[:index] + \
                            '\n' + translated_answer[index-1:]
                        break

        else:
            seperated_answer = answer.split('\n')
            translated_seperated_answer = list()
            for line in seperated_answer:
                if len(line) > 130:
                    for i in range(0, 141):
                        val = line[::-1][i]
                        if val == ' ':
                            index = -i
                            line = line[:index] + '\n' + line[index-1:]
                            break
                translated_seperated_answer.append(
                    translator_to_output_lang.translate(line))

            translated_answer = ''

            for line in translated_seperated_answer:
                translated_answer = translated_answer + '\n' + line



        last_answer = answer
        textbox.config(state=NORMAL)
        entry.delete(0, END)
        textbox.insert(END, '\n', 'direction')
        if printHead == '<':
            textbox.insert(END, direct_user_input + printHead, 'direction')
        else:
            textbox.insert(END, printHead + direct_user_input, 'direction')
        textbox.insert(END, '\n', 'direction')
        textbox.insert(END, translated_answer, 'direction')


        scroll_to_bottom(textbox)
        textbox.config(state=DISABLED)
        win.config(cursor='arrow')
        textbox.config(cursor='arrow')
        entry.config(cursor='xterm')
        drop.config(cursor='hand2')
        lf.config(cursor='arrow')
    except IndexError:
        print('problem')



entry.bind('<Return>', talk)

lf = LabelFrame(win, text='🌎Aא', bg='black', fg='white' )
lf.pack(side=TOP, pady=50)

drop_show = StringVar()
drop_show.set('עברית')


def drop_func(event):
    global printHead

    new_lang = drop_show.get()

    match new_lang:
        case 'עברית':
            translator_to_output_lang.__init__(target='iw', source='en')
            translator_to_english.__init__(source='iw', target='en')
            textbox.tag_configure('direction', justify='right')
            printHead = '<'
        case 'English':
            translator_to_output_lang.__init__(target='en', source='en')
            translator_to_english.__init__(source='en', target='en')
            textbox.tag_configure('direction', justify='left')
            printHead = '>'
        case 'ייִדיש':
            translator_to_output_lang.__init__(target='yi', source='en')
            translator_to_english.__init__(source='yi', target='en')
            textbox.tag_configure('direction', justify='right')
            printHead = '<'
        case 'فارسی':
            translator_to_output_lang.__init__(target='fa', source='en')
            translator_to_english.__init__(source='fa', target='en')
            textbox.tag_configure('direction', justify='right')
            printHead = '<'
        case 'Español':
            translator_to_output_lang.__init__(target='es', source='en')
            translator_to_english.__init__(source='es', target='en')
            textbox.tag_configure('direction', justify='left')
            printHead = '>'

    textbox.config(state=NORMAL)
    textbox.insert(END, '\n', 'direction')
    textbox.insert(END, '-'*50, 'direction')
    textbox.insert(END, '\n', 'direction')
    textbox.insert(END, (translator_to_output_lang.translate('System: ')) +
                   (translator_to_output_lang.translate(f'language was changed to {new_lang}')), 'direction')
    textbox.insert(END, '\n', 'direction')
    textbox.insert(END, '-'*50, 'direction')
    scroll_to_bottom(textbox)
    textbox.config(state=DISABLED)


drop = OptionMenu(
    lf, drop_show, *['עברית', 'English', 'ייִדיש', 'فارسی', 'Español'], command=drop_func)
drop.pack(side=TOP)


while True:  # modified mainloop:
    if not is_win_open:  # close program at end...
        break
    win.update()  # "mainlooping" once
